<?php

use Web3\Web3;
use Web3\Contract;
use Web3p\EthereumTx\Transaction;
use Web3\Utils;

class C9Web3
{
    private $contractAddress;
    private $contractABI;
    private $contract;
    private $rpc;
    private $web3;
    private $eth;
    private $nonce;
                
    //error_log('abi:'. $contractABI);

    public function __construct()
    {
        $this->contractABI = file_get_contents('/var/www/html/financiamento/nft.abi');
        $this->contractAddress = '0x9554dee4d95d7253ab77c00f7e341d2ad2dd3598';
        $this->rpc = 'https://rpc.testnet.tomochain.com';

        $this->web3 = new Web3($this->rpc);
        $this->eth =  $this->web3->eth;

        $this->contract = new Contract($this->web3->provider, $this->contractABI);

    }
    
    public function LerValorTotalEmContrato()
    {

        $this->contract->at($this->contractAddress)->call('LerValorTotalEmContrato', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });                
    }
    
    public function ValorTotalAbertoEmContrato()
    {

        $this->contract->at($this->contractAddress)->call('ValorTotalAbertoEmContrato', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });                
        
    }
    
    public function ValorTotalDividaEmContrato()
    {

        $this->contract->at($this->contractAddress)->call('ValorTotalDividaEmContrato', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });            
    }

    public function CriarNFT($privateKey,$fromAddress,$agente_comprador,$agente_garantidor,$valorDoBem)
    {

        error_log("===== chegou");
        
        $this->eth->getTransactionCount($fromAddress,function($err,$res)
        {
            
            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Nonce consultado: ' . $res);
            
            $this->nonce=$res->value;
            return $res;
        });

        $nonce = '0x' . dechex($this->nonce);
        error_log($nonce);
        $nonce = Utils::toHex($nonce);

        error_log('p2');
        $gasPrice = Utils::toHex(10000000000); //Utils::toWei('10', 'gwei')); // Substitua com o preço do gás desejado - 10000000000
        $gasLimit = Utils::toHex(200000); // Substitua com o limite de gás desejado
        error_log('p3');
        $valorDoBem = bcmul($valorDoBem, bcpow('10', '18'));
        $valorDoBem = Utils::toHex($valorDoBem, true);
        $valorDoBem = Utils::toBn($valorDoBem);

        //$function = $this->contractAddress->at($this->contractAddress)->getData('CriarNFT');
        error_log($agente_comprador);
        error_log($agente_garantidor);
        error_log($valorDoBem);
        $function = $this->contract->at($this->contractAddress)->getData('CriarNFT', $agente_comprador,$agente_garantidor,$valorDoBem);

        error_log("passou..");
        error_log($function);
        
        error_log($nonce);
        error_log($gasPrice);
        error_log($gasLimit);
        error_log($this->contractAddress);
        error_log(0x0);
        error_log($nonce);
        
        
        $transaction = new Transaction([
            'nonce' => $nonce,
            'gasPrice' => $gasPrice,
            'gasLimit' => $gasLimit,
            'to' => $this->contractAddress,
            'value' => Utils::toHex(0),
            'data' => $function
        ]);

        error_log('assinando:' . $privateKey);
        $signedTransaction = $transaction->sign($privateKey);

        error_log('Transacao assinada: 0x' . $signedTransaction);

        $this->eth->sendRawTransaction('0x' . $signedTransaction, function ($err, $tx) {

            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            var_dump($tx);
            error_log('Transação enviada! Hash da transação: ' . $tx);
            exit;
            return $tx;
        });
    }

    public function AssumirComoFiador($tokenId,$bankAddress)
    {
        
    }

    public function EnviarDrex($tokenId,$Valor)
    {
        
    }
    
    public function EnviarDrexTokenizado($tokenId, $Valor)
    {
        
    }

    public function PagarDebito($tokenId,$ValorPago) 
    {
        
    }

    public function PagarDebitoFiador($tokenId,$ValorPago)
    {
        
    }

    public function LerFiador($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('LerFiador', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });          
    }

    public function LerGarantidor($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('LerGarantidor', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });           
    }

    public function LerComprador($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('LerComprador', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });           
    }

    public function valorDoBem($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('valorDoBem', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });           
    }

    public function valorDoDebitoAtual($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('valorDoDebitoAtual', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });           
    }

    public function valorSaldoDrex($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('valorSaldoDrex', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });           
    }

    public function valorSaldoDrexTokenizado($tokenId)
    {
        $this->contract->at($this->contractAddress)->call('valorSaldoDrexTokenizado', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });           
    }

}