<?php

use Web3\Web3;
use Web3\Contract;

class W3Work
{
    private $contractAddress;
    private $contractABI;
    private $contract;
    private $rpc;
    private $web3;
    private $contract;
    private $eth;
                
    //error_log('abi:'. $contractABI);

    public function constructor()
    {
        $this->contractABI = file_get_contents('/var/www/html/financiamento/nft.abi');
        $this->contractAddress = '0x9554dee4d95d7253ab77c00f7e341d2ad2dd3598';
        $this->rpc = 'https://rpc.testnet.tomochain.com';

        $this->web3 = new Web3($this->rpc);

        $this->contract = new Contract($this->web3->provider, $this->contractABI);
    }
    
    public function LerValorTotalEmContrato()
    {

        error_log('chegou aqui =============');
        $this->contract->at(this::contractAddress)->call('LerValorTotalEmContrato', function ($err, $result) {
                    if ($err !== null) {
                        return;
                    }

                    if ($result) {
                        var_dump($result);
                        return $result[0];
                    }
                });                
    }

    
}