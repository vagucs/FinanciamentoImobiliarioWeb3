<?php

use Web3\Web3;
use Web3\Contract;
use Web3p\EthereumTx\Transaction;
use Web3\Utils;

class C9Web3
{
    private $contractAddress;
    private $contractABI;
    private $contract;
    private $rpc;
    private $web3;
    private $eth;
    private $nonce;
    private $gasprice;
    private $gaslimit;
    private $hash;
    private $valid;
    private $nft;
    private $blocknumber;
    private $trstatus = 0;
                
    //error_log('abi:'. $contractABI);

    public function __construct()
    {
        $this->contractABI = file_get_contents('/var/www/html/financiamento/nft.abi');
        $this->contractAddress = '0xcc02c38ce42a3473e742a7fb2293fad039d21b43';
        $this->rpc = 'https://rpc.testnet.tomochain.com';

        $this->web3 = new Web3($this->rpc);
        $this->eth =  $this->web3->eth;

        $this->contract = new Contract($this->web3->provider, $this->contractABI);

    }
    
    public function LerValorTotalEmContrato()
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('LerValorTotalEmContrato', function ($err, $result) use (&$ret) {
            
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });                
        return $ret;
    }
    
    public function ValorTotalAbertoEmContrato()
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('ValorTotalAbertoEmContrato', function ($err, $result) use (&$ret){
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });                
        return $ret;
}
    
    public function ValorTotalDividaEmContrato()
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('ValorTotalDividaEmContrato', function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });            
        return $ret;
    }

    public function CriarNFT($privateKey,$fromAddress,$agente_comprador,$agente_garantidor,$valorDoBem)
    {

        $this->nonce=-1;
        
        $this->eth->getTransactionCount($fromAddress,function($err,$res)
        {
            
            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Nonce consultado: ' . $res);
            
            $this->nonce=$res->value;
            return $res;
        });

        if ($this->nonce==-1)
        {
            error_log('Nonce nao obtido');
            return false;
        }

        //$nonce = '0x' . dechex($this->nonce);
        error_log($this->nonce);
        $nonce = Utils::toHex((string)$this->nonce);

        $this->eth->gasPrice(function ($err, $gasPrice) {
            if ($err !== null) {
                return false;
            }
            $this->gasprice=$gasPrice->toString();
        });
        
        $gasPrice = Utils::toHex($this->gasprice);
        $gasLimit = Utils::toHex(100000000);

        $valorDoBem = bcmul($valorDoBem, bcpow('10', '18'));
        $valorDoBem = Utils::toHex($valorDoBem, true);
        $valorDoBem = Utils::toBn($valorDoBem);

        error_log($agente_comprador);
        error_log($agente_garantidor);
        error_log($valorDoBem);

        $function = $this->contract->at($this->contractAddress)->getData('CriarNFT', $agente_comprador,$agente_garantidor,$valorDoBem);

        error_log($function);
        
        error_log($nonce);
        error_log($gasPrice);
        error_log($gasLimit);
        error_log($this->contractAddress);
        error_log(0x0);
        error_log($nonce);

        /*
        $this->eth->estimateGas([
            'from' => $fromAddress,
            'to' =>  $this->contractAddress,
            'gas' => "0x76c0",
            'gasPrice' => '0x' . $gasPrice,
            'value' => "0x0",
            'data' => '0x' . $function
        ], function ($err, $gas) {
            if ($err !== null) {
            }
            var_dump($gas);
            error_log('Gas estimado:' . Utils::toBn((string)$gas->value));
        });
        */

        $transaction = new Transaction([
            'nonce' => '0x' . $nonce,
            'gasPrice' => '0x' . $gasPrice,
            'gasLimit' => '0x' . $gasLimit,
            'to' => $this->contractAddress,
            'from' => $fromAddress,
            'value' => Utils::toHex(0),
            'data' => '0x' . $function,
            'chainId' => 89
        ]);

        error_log('assinando...');
        $signedTransaction = $transaction->sign($privateKey);

        $this->hash='';
        error_log('Transacao assinada: 0x' . $signedTransaction);

        /*$this->eth->sendRawTransaction('0x' . $signedTransaction, function ($err, $tx) {

            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Transação enviada! Hash da transação: ' . $tx);
            $this->hash=$tx;
        });*/
        
        $this->hash='0x880323dc0df75a75e9fc9d10fc477f8695f36812cc07b0e70eb66e3cadf5b116'; //$this->hash;
        
        $this->blocknumber=0;
        
        error_log('Verificando transacao:' . $this->hash);
        
        $this->trstatus=-1;
        
        if (!empty($this->hash))
        {
            for($i=0;$i<30;$i++)
            {
                $this->eth->getTransactionReceipt($this->hash, function ($err, $transaction) {
                    if ($err !== null) {
                        error_log('Nao encontrada');
                        return $this->fail($err->getMessage());
                    }
                    
                    if (gettype($transaction)==='object')
                    {
                        error_log(json_encode($transaction));
                        
                        $this->nft = hexdec(substr($transaction->logs[0]->topics[3],-16)); // Indice do NFT
                        $this->valid = $transaction->logs[0]->removed;
                        $this->blocknumber = hexdec(substr($transaction->blockNumber,-16));
                        $this->trstatus = $transaction->status;
                        
                        error_log("NFT -> " . $this->nft);
                    }
                    
                    //$this->assertTrue($transaction == null);
                });

                if (!($this->trstatus===-1))
                {
                    if ($this->trstatus==='0x1')
                    {
                        break;
                    }else{
                        error_log('Esperando confirmacao');
                        break;
                    }
                }
                sleep(1);
            }

        }

        if ($this->trstatus==='0x1')
        {
            return [$this->nft,$this->blocknumber,$this->hash];
        }else{
            return false;
        }

        /*
        { ["blockHash"]=> string(66) "0x20dae25773e6cc0dead9b74f1a602c91b34d963830021739c41f2b5eca80b14c" 
          ["blockNumber"]=> string(9) "0x2d1b5cb" 
          ["contractAddress"]=> NULL 
          ["cumulativeGasUsed"]=> string(7) "0x3abea" 
          ["from"]=> string(42) "0xeee3215d15ff5aa879675a7738d076681482d7df" 
          ["gasUsed"]=> string(7) "0x3abea" 
          ["logs"]=> array(1) { [0]=> object(stdClass)#1933 (9) 
                                    { 
                                        ["address"]=> string(42) "0x9554dee4d95d7253ab77c00f7e341d2ad2dd3598" 
                                        ["topics"]=> array(4) { [0]=> string(66) "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef" 
                                                                [1]=> string(66) "0x0000000000000000000000000000000000000000000000000000000000000000" 
                                                                [2]=> string(66) "0x0000000000000000000000004319ad76b811468f56be89e8877616e24f6e03bd" 
                                                                [3]=> string(66) "0x0000000000000000000000000000000000000000000000000000000000000001" 
                                                              } 
                                        ["data"]=> string(2) "0x" 
                                        ["blockNumber"]=> string(9) "0x2d1b5cb" 
                                        ["transactionHash"]=> string(66) "0x187cf40bac9d1a78111a107f30308c13ae53bb732e91c14dfb7618bf8ec2c207" 
                                        ["transactionIndex"]=> string(3) "0x1" 
                                        ["blockHash"]=> string(66) "0x20dae25773e6cc0dead9b74f1a602c91b34d963830021739c41f2b5eca80b14c" 
                                        ["logIndex"]=> string(3) "0x1" 
                                        ["removed"]=> bool(false) 
                                    } 
                             } 
          ["logsBloom"]=> string(514) "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000040000000000000000000000800008000000000000000000040000000000000000000000000000020000000000000000000800000000000000200000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000001000060000000000800020000000000000000000000000000000000000000000000000000" 
          ["status"]=> string(3) "0x1" 
          ["to"]=> string(42) "0x9554dee4d95d7253ab77c00f7e341d2ad2dd3598" 
          ["transactionHash"]=> string(66) "0x187cf40bac9d1a78111a107f30308c13ae53bb732e91c14dfb7618bf8ec2c207" 
          ["transactionIndex"]=> string(3) "0x1" }
        */
    }

    public function AssumirComoFinanciador($privateKey,$fromAddress,$tokenId)
    {

        $this->nonce=-1;
        
        error_log('Obtendo nonce para ' . $fromAddress);
        
        $this->eth->getTransactionCount($fromAddress,function($err,$res)
        {
            
            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Nonce consultado: ' . $res);
            
            $this->nonce=$res->value;
            return $res;
        });

        if ($this->nonce==-1)
        {
            error_log('Nonce nao obtido');
            return false;
        }

        //$nonce = '0x' . dechex($this->nonce);
        error_log($this->nonce);
        $nonce = Utils::toHex((string)$this->nonce);

        $this->eth->gasPrice(function ($err, $gasPrice) {
            if ($err !== null) {
                return false;
            }
            $this->gasprice=$gasPrice->toString();
        });
        
        $gasPrice = Utils::toHex($this->gasprice);
        $gasLimit = Utils::toHex(100000000);

        error_log($tokenId);
        error_log($bankAddress);

        $function = $this->contract->at($this->contractAddress)->getData('AssumirComoFinanciador', $tokenId);

        error_log($function);
        
        error_log($nonce);
        error_log($gasPrice);
        error_log($gasLimit);
        error_log($this->contractAddress);
        error_log(0x0);
        error_log($nonce);

        $transaction = new Transaction([
            'nonce' => '0x' . $nonce,
            'gasPrice' => '0x' . $gasPrice,
            'gasLimit' => '0x' . $gasLimit,
            'to' => $this->contractAddress,
            'from' => $fromAddress,
            'value' => Utils::toHex(0),
            'data' => '0x' . $function,
            'chainId' => 89
        ]);

        error_log('assinando...');
        $signedTransaction = $transaction->sign($privateKey);

        $this->hash='';
        error_log('Transacao assinada: 0x' . $signedTransaction);

        $this->eth->sendRawTransaction('0x' . $signedTransaction, function ($err, $tx) {

            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Transação enviada! Hash da transação: ' . $tx);
            $this->hash=$tx;
        });
        
        $this->blocknumber=0;
        
        error_log('Verificando transacao:' . $this->hash);
        
        $this->trstatus=-1;
        
        if (!empty($this->hash))
        {
            for($i=0;$i<30;$i++)
            {
                $this->eth->getTransactionReceipt($this->hash, function ($err, $transaction) {
                    if ($err !== null) {
                        error_log('Nao encontrada');
                        return $this->fail($err->getMessage());
                    }

                    if (gettype($transaction)==='object')
                    {
                        error_log(json_encode($transaction));
                        
                        error_log("Estado:" . $transaction->status);
                        
                        $this->trstatus = $transaction->status;
                    }

                    //$this->assertTrue($transaction == null);
                });

                if (!($this->trstatus===-1))
                {
                    if ($this->trstatus==='0x1')
                    {
                        break;
                    }else{
                        error_log('Esperando confirmacao');
                        break;
                    }
                }
                sleep(1);
            }

        }

        if ($this->trstatus==='0x1')
        {
            return [$this->nft,$this->blocknumber,$this->hash];
        }else{
            return false;
        }
    }

    public function EnviarDrex($privateKey,$fromAddress,$tokenId)
    {

        $this->nonce=-1;
        
        error_log('Obtendo nonce para ' . $fromAddress);
        
        $this->eth->getTransactionCount($fromAddress,function($err,$res)
        {
            
            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Nonce consultado: ' . $res);
            
            $this->nonce=$res->value;
            return $res;
        });

        if ($this->nonce==-1)
        {
            error_log('Nonce nao obtido');
            return false;
        }

        //$nonce = '0x' . dechex($this->nonce);
        error_log($this->nonce);
        $nonce = Utils::toHex((string)$this->nonce);

        $this->eth->gasPrice(function ($err, $gasPrice) {
            if ($err !== null) {
                return false;
            }
            $this->gasprice=$gasPrice->toString();
        });
        
        $gasPrice = Utils::toHex($this->gasprice);
        $gasLimit = Utils::toHex(100000000);

        error_log($tokenId);
        error_log($bankAddress);

        $function = $this->contract->at($this->contractAddress)->getData('EnviarDrex', $tokenId);

        error_log($function);
        
        error_log($nonce);
        error_log($gasPrice);
        error_log($gasLimit);
        error_log($this->contractAddress);
        error_log(0x0);
        error_log($nonce);

        $transaction = new Transaction([
            'nonce' => '0x' . $nonce,
            'gasPrice' => '0x' . $gasPrice,
            'gasLimit' => '0x' . $gasLimit,
            'to' => $this->contractAddress,
            'from' => $fromAddress,
            'value' => Utils::toHex(0),
            'data' => '0x' . $function,
            'chainId' => 89
        ]);

        error_log('assinando...');
        $signedTransaction = $transaction->sign($privateKey);

        $this->hash='';
        error_log('Transacao assinada: 0x' . $signedTransaction);

        $this->eth->sendRawTransaction('0x' . $signedTransaction, function ($err, $tx) {

            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Transação enviada! Hash da transação: ' . $tx);
            $this->hash=$tx;
        });
        
        $this->blocknumber=0;
        
        error_log('Verificando transacao:' . $this->hash);
        
        $this->trstatus=-1;
        
        if (!empty($this->hash))
        {
            for($i=0;$i<30;$i++)
            {
                $this->eth->getTransactionReceipt($this->hash, function ($err, $transaction) {
                    if ($err !== null) {
                        error_log('Nao encontrada');
                        return $this->fail($err->getMessage());
                    }

                    if (gettype($transaction)==='object')
                    {
                        error_log(json_encode($transaction));
                        
                        error_log("Estado:" . $transaction->status);
                        
                        $this->trstatus = $transaction->status;
                    }

                    //$this->assertTrue($transaction == null);
                });

                if (!($this->trstatus===-1))
                {
                    if ($this->trstatus==='0x1')
                    {
                        error_log('ok');
                        break;
                    }else{
                        error_log('Esperando confirmacao');
                        break;
                    }
                }
                sleep(1);
            }

        }

        if ($this->trstatus==='0x1')
        {
            return [$this->nft,$this->blocknumber,$this->hash];
        }else{
            return false;
        }        
    }
    
    public function EnviarDrexTokenizado($privateKey,$fromAddress,$tokenId,$valorDoBem)
    {

        $this->nonce=-1;
        
        error_log('Obtendo nonce para ' . $fromAddress);
        
        $this->eth->getTransactionCount($fromAddress,function($err,$res)
        {
            
            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Nonce consultado: ' . $res);
            
            $this->nonce=$res->value;
            return $res;
        });

        if ($this->nonce==-1)
        {
            error_log('Nonce nao obtido');
            return false;
        }

        //$nonce = '0x' . dechex($this->nonce);
        error_log($this->nonce);
        $nonce = Utils::toHex((string)$this->nonce);

        $this->eth->gasPrice(function ($err, $gasPrice) {
            if ($err !== null) {
                return false;
            }
            $this->gasprice=$gasPrice->toString();
        });
        
        $gasPrice = Utils::toHex($this->gasprice);
        $gasLimit = Utils::toHex(100000000);

        error_log($tokenId);
        error_log($bankAddress);

        $valorDoBem = bcmul($valorDoBem, bcpow('10', '18'));
        $valorDoBem = Utils::toHex($valorDoBem, true);
        $valorDoBem = Utils::toBn($valorDoBem);


        $function = $this->contract->at($this->contractAddress)->getData('EnviarDrexTokenizado', $tokenId, $valorDoBem);

        error_log($function);
        
        error_log($nonce);
        error_log($gasPrice);
        error_log($gasLimit);
        error_log($this->contractAddress);
        error_log(0x0);
        error_log($nonce);

        $transaction = new Transaction([
            'nonce' => '0x' . $nonce,
            'gasPrice' => '0x' . $gasPrice,
            'gasLimit' => '0x' . $gasLimit,
            'to' => $this->contractAddress,
            'from' => $fromAddress,
            'value' => Utils::toHex(0),
            'data' => '0x' . $function,
            'chainId' => 89
        ]);

        error_log('assinando...');
        $signedTransaction = $transaction->sign($privateKey);

        $this->hash='';
        error_log('Transacao assinada: 0x' . $signedTransaction);

        $this->eth->sendRawTransaction('0x' . $signedTransaction, function ($err, $tx) {

            if ($err !== null) {
                error_log('Erro: ' . $err->getMessage());
                return false;
            }

            error_log('Transação enviada! Hash da transação: ' . $tx);
            $this->hash=$tx;
        });
        
        $this->blocknumber=0;
        
        error_log('Verificando transacao:' . $this->hash);
        
        $this->trstatus=-1;
        
        if (!empty($this->hash))
        {
            for($i=0;$i<30;$i++)
            {
                $this->eth->getTransactionReceipt($this->hash, function ($err, $transaction) {
                    if ($err !== null) {
                        error_log('Nao encontrada');
                        return $this->fail($err->getMessage());
                    }

                    if (gettype($transaction)==='object')
                    {
                        error_log(json_encode($transaction));
                        
                        error_log("Estado:" . $transaction->status);
                        
                        $this->trstatus = $transaction->status;
                    }

                    //$this->assertTrue($transaction == null);
                });

                if (!($this->trstatus===-1))
                {
                    if ($this->trstatus==='0x1')
                    {
                        error_log('ok');
                        break;
                    }else{
                        error_log('Esperando confirmacao');
                        break;
                    }
                }
                sleep(1);
            }

        }

        if ($this->trstatus==='0x1')
        {
            return [$this->nft,$this->blocknumber,$this->hash];
        }else{
            return false;
        }        
        
    }

    public function PagarDebito($tokenId,$ValorPago) 
    {
        
    }

    public function PagarDebitoFiador($tokenId,$ValorPago)
    {
        
    }

    public function LerFinanciador($tokenId)
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('LerFinanciador',$tokenId, function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret = $result[0];
                });
        return $ret;
    }

    public function LerGarantidor($tokenId)
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('LerGarantidor',$tokenId, function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret = $result[0];
                });
        return $ret;
    }

    public function LerComprador($tokenId)
    {
        $ret = '';
                $this->contract->at($this->contractAddress)->call('LerComprador',$tokenId, function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret = $result[0];
                });
        return $ret;
    }

    public function valorDoBem($tokenId)
    {
        $ret='';
        $this->contract->at($this->contractAddress)->call('valorDoBem',$tokenId, function ($err, $result) use (&$ret){
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });
        return $ret;
    }
    
    static function w3monetario($x)
    {
        $dec=substr($x,-18);
        $x=substr($x,0,strlen($x)-18);
        $valor=$x . '.' . $dec;
        return (float) $valor;
    }

    public function valorDoDebitoAtual($tokenId)
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('valorDoDebitoAtual',$tokenId, function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });
        return $ret;
    }

    public function valorSaldoDrex($tokenId)
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('valorSaldoDrex',$tokenId, function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });
        return $ret;
    }

    public function valorSaldoDrexTokenizado($tokenId)
    {
        $ret = '';
        $this->contract->at($this->contractAddress)->call('valorSaldoDrexTokenizado',$tokenId, function ($err, $result) use (&$ret) {
                    if ($err !== null) {
                        return;
                    }
                    $ret=C9Web3::w3monetario($result[0]);
                });
        return $ret;
    }

}